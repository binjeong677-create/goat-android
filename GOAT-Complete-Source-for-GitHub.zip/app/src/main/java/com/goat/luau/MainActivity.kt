package com.goat.luau

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalContext
import java.io.File

private val Bg = Color(0xFF090909)
private val Panel = Color(0xFF171717)
private val Red = Color(0xFFFF3030)
private val Muted = Color(0xFF9A9A9A)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { GoatApp() }
    }
}

@Composable
fun GoatApp() {
    val context = LocalContext.current
    var code by remember { mutableStateOf("-- GOAT Luau Editor\n-- Write and save your Luau scripts here.\n\nprint(\"Hello, GOAT!\")") }
    var fileName by remember { mutableStateOf("script.lua") }
    var status by remember { mutableStateOf("Ready") }
    var console by remember { mutableStateOf("GOAT console initialized.\nStandalone editor mode.") }
    var showFiles by remember { mutableStateOf(false) }
    val scriptsDir = remember { File(context.filesDir, "scripts").apply { mkdirs() } }

    MaterialTheme(colorScheme = darkColorScheme(background = Bg, surface = Panel, primary = Red)) {
        Column(Modifier.fillMaxSize().background(Bg).padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.weight(1f)) {
                    Text("GOAT", color = Red, fontSize = 30.sp, fontFamily = FontFamily.Monospace)
                    Text("LUAU DEVELOPMENT STUDIO", color = Muted, fontSize = 10.sp, letterSpacing = 2.sp)
                }
                Surface(color = Color(0xFF301010), shape = RoundedCornerShape(20.dp)) {
                    Text("ANDROID", color = Red, modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp), fontSize = 11.sp)
                }
            }
            Spacer(Modifier.height(16.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(value = fileName, onValueChange = { fileName = it }, modifier = Modifier.weight(1f), singleLine = true, label = { Text("File name") })
                Spacer(Modifier.width(8.dp))
                Button(onClick = {
                    val safe = fileName.substringAfterLast('/').ifBlank { "script.lua" }
                    File(scriptsDir, safe).writeText(code)
                    status = "Saved: $safe"
                }, colors = ButtonDefaults.buttonColors(containerColor = Red)) { Icon(Icons.Default.Save, "Save") }
            }
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { showFiles = true }) { Icon(Icons.Default.FolderOpen, null); Spacer(Modifier.width(4.dp)); Text("OPEN") }
                OutlinedButton(onClick = { code = "-- New Luau script\n\n" }) { Icon(Icons.Default.Add, null); Spacer(Modifier.width(4.dp)); Text("NEW") }
            }
            Spacer(Modifier.height(10.dp))
            Text("EDITOR / LUAU", color = Red, fontSize = 12.sp, letterSpacing = 1.5.sp)
            Spacer(Modifier.height(6.dp))
            Surface(Modifier.weight(1f).fillMaxWidth(), color = Panel, shape = RoundedCornerShape(12.dp), border = BorderStroke(1.dp, Color(0xFF343434))) {
                BasicTextField(value = code, onValueChange = { code = it }, modifier = Modifier.fillMaxSize().padding(14.dp).verticalScroll(rememberScrollState()),
                    textStyle = TextStyle(color = Color(0xFFE8E8E8), fontSize = 14.sp, fontFamily = FontFamily.Monospace, lineHeight = 21.sp),
                    cursorBrush = SolidColor(Red))
            }
            Spacer(Modifier.height(10.dp))
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(onClick = {
                    console = "Prepared ${code.lines().size} lines.\nUse Roblox Studio or another authorized Luau runtime to execute scripts."
                    status = "Prepared"
                }, colors = ButtonDefaults.buttonColors(containerColor = Red), modifier = Modifier.weight(1f)) {
                    Icon(Icons.Default.PlayArrow, null); Spacer(Modifier.width(5.dp)); Text("PREPARE")
                }
                OutlinedButton(onClick = { console = "Console cleared."; status = "Ready" }) { Icon(Icons.Default.DeleteSweep, null) }
            }
            Spacer(Modifier.height(8.dp))
            Surface(color = Panel, shape = RoundedCornerShape(10.dp), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("CONSOLE", color = Red, fontSize = 11.sp, letterSpacing = 1.3.sp)
                        Spacer(Modifier.weight(1f)); Text(status, color = Muted, fontSize = 10.sp)
                    }
                    Spacer(Modifier.height(5.dp))
                    Text(console, color = Color(0xFFBDBDBD), fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                }
            }
            Spacer(Modifier.height(5.dp))
            Text("GOAT v1.0 • Standalone Luau editor", color = Color(0xFF666666), fontSize = 10.sp, modifier = Modifier.align(Alignment.CenterHorizontally))
        }
        if (showFiles) AlertDialog(
            onDismissRequest = { showFiles = false }, containerColor = Panel, title = { Text("Saved scripts") },
            text = {
                val saved = scriptsDir.listFiles()?.sortedBy { it.name } ?: emptyList()
                if (saved.isEmpty()) Text("No saved scripts yet.")
                else Column(Modifier.heightIn(max = 280.dp).verticalScroll(rememberScrollState())) {
                    saved.forEach { f -> TextButton(onClick = { code = f.readText(); fileName = f.name; status = "Opened ${f.name}"; showFiles = false }) { Text(f.name, color = Color.White) } }
                }
            },
            confirmButton = { TextButton(onClick = { showFiles = false }) { Text("CLOSE", color = Red) } }
        )
    }
}
