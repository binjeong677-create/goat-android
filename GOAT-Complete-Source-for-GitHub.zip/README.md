# GOAT Android Luau Editor

Complete Android source project for GOAT, a standalone Luau editor with local save/open and a console status panel.

## Upload from Android
1. Download and extract this ZIP on your tablet.
2. In your GitHub repository, choose **Add file → Upload files**.
3. Upload all extracted files and folders from the archive root into the repository root. Include `.github`. Replace `.github/workflows/blank.yml` if GitHub asks.
4. Commit the upload to `main`.
5. Open **Actions → Build GOAT APK**. The workflow starts automatically after the upload.
6. When successful, open the run and download the `GOAT-debug-apk` artifact. Extract it and install `app-debug.apk`.

The workflow uses Ubuntu 24.04, Java 17, and Gradle 8.9 on GitHub-hosted runners.

## Scope
This is an independent Luau editor. It does not inject code into Roblox or bypass Roblox protections.
